package ru.vypiski.app

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

/**
 * 12.77.10: what happened when the app stopped unexpectedly — kept on the device so the user can send it.
 * Only technical facts (time, reason, memory); never order texts, names or files. Nothing is sent anywhere.
 */
object CrashLog {
    private const val PREFS = "vypiski"
    private const val KEY = "crash_log"
    private const val TRIM = "trim_log"
    private const val SEEN = "exit_seen"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun append(ctx: Context, key: String, e: JSONObject, max: Int) {
        try {
            val p = prefs(ctx)
            val arr = try { JSONArray(p.getString(key, "[]")) } catch (_: Exception) { JSONArray() }
            arr.put(e)
            val out = JSONArray()
            val from = maxOf(0, arr.length() - max)
            for (i in from until arr.length()) out.put(arr.get(i))
            p.edit().putString(key, out.toString()).commit() // commit: the process may be about to die
        } catch (_: Exception) { }
    }

    fun add(ctx: Context, e: JSONObject) = append(ctx, KEY, e.put("version", BuildConfigVersion.name(ctx)), 30)

    fun trim(ctx: Context, level: Int) = append(ctx, TRIM, JSONObject().put("at", System.currentTimeMillis()).put("level", level).put("memory", memory(ctx)), 15)

    fun read(ctx: Context): String = try {
        JSONObject()
            .put("log", JSONArray(prefs(ctx).getString(KEY, "[]")))
            .put("trim", JSONArray(prefs(ctx).getString(TRIM, "[]")))
            .put("memory", memory(ctx))
            .put("device", JSONObject().put("model", Build.MANUFACTURER + " " + Build.MODEL).put("android", Build.VERSION.RELEASE).put("sdk", Build.VERSION.SDK_INT))
            .toString()
    } catch (e: Exception) { "{}" }

    fun clear(ctx: Context) { prefs(ctx).edit().remove(KEY).remove(TRIM).apply() }

    fun memory(ctx: Context): JSONObject {
        val o = JSONObject()
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
            o.put("availMb", mi.availMem / 1048576).put("totalMb", mi.totalMem / 1048576).put("low", mi.lowMemory).put("thresholdMb", mi.threshold / 1048576)
                .put("appLimitMb", am.memoryClass).put("appLargeLimitMb", am.largeMemoryClass)
            val rt = Runtime.getRuntime()
            o.put("javaUsedMb", (rt.totalMemory() - rt.freeMemory()) / 1048576)
        } catch (_: Exception) { }
        return o
    }

    private fun reasonName(r: Int) = when (r) {
        1 -> "приложение завершилось само"; 2 -> "остановлено сигналом системы"; 3 -> "нехватка памяти (система закрыла приложение)"
        4 -> "сбой программы"; 5 -> "сбой встроенного кода"; 6 -> "приложение не отвечало (ANR)"; 7 -> "ошибка запуска"
        8 -> "изменены разрешения"; 9 -> "слишком много ресурсов"; 10 -> "закрыто пользователем"; 11 -> "остановлено пользователем"
        12 -> "закрылся связанный процесс"; 13 -> "другая причина"; 14 -> "заморожено системой"; 15 -> "изменение пакета"; 16 -> "обновление приложения"
        else -> "неизвестно"
    }

    /** Android 11+: the system remembers why the app's process ended last time. */
    fun collectExitReasons(ctx: Context) {
        if (Build.VERSION.SDK_INT < 30) return
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val seen = prefs(ctx).getLong(SEEN, 0L)
            var max = seen
            for (r in am.getHistoricalProcessExitReasons(ctx.packageName, 0, 10).sortedBy { it.timestamp }) {
                if (r.timestamp <= seen) continue
                max = maxOf(max, r.timestamp)
                if (seen == 0L) continue // first run of this version: only remember where we are
                val user = r.reason == 10 || r.reason == 11 || r.reason == 16
                append(ctx, KEY, JSONObject().put("type", "exit").put("at", r.timestamp).put("reason", r.reason).put("reasonText", reasonName(r.reason))
                    .put("byUser", user).put("status", r.status).put("importance", r.importance).put("pssMb", r.pss / 1024).put("rssMb", r.rss / 1024)
                    .put("description", (r.description ?: "").take(300)).put("version", BuildConfigVersion.name(ctx)), 30)
            }
            prefs(ctx).edit().putLong(SEEN, if (max == 0L) System.currentTimeMillis() else max).apply()
        } catch (_: Exception) { }
    }

    /** A crash of the app's own (Kotlin) code: record it, then let Android handle it as usual. */
    fun installHandler(ctx: Context) {
        val app = ctx.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        if (prev is Handler) return
        Thread.setDefaultUncaughtExceptionHandler(Handler(app, prev))
    }

    private class Handler(val ctx: Context, val prev: Thread.UncaughtExceptionHandler?) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            try {
                add(ctx, JSONObject().put("type", "native").put("at", System.currentTimeMillis()).put("thread", t.name)
                    .put("error", (e.toString() + "\n" + e.stackTrace.take(12).joinToString("\n") { "  at $it" }).take(3000)).put("memory", memory(ctx)))
            } catch (_: Exception) { }
            prev?.uncaughtException(t, e)
        }
    }
}

private object BuildConfigVersion {
    fun name(ctx: Context): String = try {
        @Suppress("DEPRECATION") ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (_: Exception) { "" }
}
