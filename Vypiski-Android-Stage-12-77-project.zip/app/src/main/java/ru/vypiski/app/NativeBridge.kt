package ru.vypiski.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Bridge exposed to the page as window.VypiskiNative. Every method is called on the WebView's JavaBridge thread.
 * Long work runs on [io]; results are delivered back with VypiskiNativeEvents.resolve(id, json).
 */
class NativeBridge(private val activity: MainActivity) {

    private class Entry(val path: String, val size: Long, val uri: Uri, val mtime: Long)
    private class SaveJob(val name: String, val mime: String, val file: File, val out: FileOutputStream)

    private val io = Executors.newSingleThreadExecutor()
    private val jobs = ConcurrentHashMap<String, List<Entry>>()
    private val saves = ConcurrentHashMap<String, SaveJob>()
    private val printViews = mutableListOf<WebView>()
    @Volatile private var pendingImport: String? = null
    @Volatile private var pendingExport: String? = null
    private val prefs by lazy { activity.getSharedPreferences("vypiski", Context.MODE_PRIVATE) }

    // ---------- events back to the page ----------
    private fun resolve(id: String, json: JSONObject) =
        activity.js("window.VypiskiNativeEvents&&VypiskiNativeEvents.resolve(${JSONObject.quote(id)},${json})")

    private fun progress(id: String, json: JSONObject) =
        activity.js("window.VypiskiNativeEvents&&VypiskiNativeEvents.progress(${JSONObject.quote(id)},${json})")

    private fun error(id: String, e: Throwable) = resolve(id, JSONObject().put("error", e.message ?: e.toString()))

    @JavascriptInterface fun version(): String = "12.77.6"

    @JavascriptInterface fun keepAwake(on: Boolean) = activity.keepScreenOn(on)

    // ---------- whole-folder import (Storage Access Framework, read only) ----------
    @JavascriptInterface
    fun pickFolder(id: String) {
        pendingImport = id
        activity.runOnUiThread {
            try { activity.pickImportTree.launch(null) } catch (e: Exception) { pendingImport = null; error(id, e) }
        }
    }

    /** Continue an interrupted import: list the same folder again without the picker (read permission was persisted). */
    @JavascriptInterface
    fun rescanFolder(id: String, tree: String) {
        val uri = try { Uri.parse(tree) } catch (e: Exception) { null }
        val granted = uri != null && activity.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
        if (!granted) { resolve(id, JSONObject().put("error", "Нет доступа к папке — выберите её заново")); return }
        io.execute { try { scan(id, uri!!) } catch (e: Throwable) { error(id, e) } }
    }

    fun onImportTreePicked(uri: Uri?) {
        val id = pendingImport ?: return
        pendingImport = null
        if (uri == null) { resolve(id, JSONObject().put("cancelled", true)); return }
        io.execute {
            try { scan(id, uri) } catch (e: Throwable) { error(id, e) }
        }
    }

    /** One query per directory (not per file): thousands of files are listed in seconds, nothing is copied. */
    private fun scan(id: String, tree: Uri) {
        val cr = activity.contentResolver
        try { cr.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val rootName = displayName(DocumentsContract.buildDocumentUriUsingTree(tree, rootId)) ?: "Папка"
        val list = ArrayList<Entry>()
        var locks = 0; var other = 0; var dirs = 0; var seen = 0
        val queue = ArrayDeque<Pair<String, String>>()
        queue.add(rootId to rootName)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        while (queue.isNotEmpty()) {
            val (docId, prefix) = queue.removeFirst()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            cr.query(children, projection, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val childId = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2) ?: ""
                    val size = if (c.isNull(3)) -1L else c.getLong(3)
                    val mtime = if (c.isNull(4)) 0L else c.getLong(4)
                    val path = "$prefix/$name"
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) { dirs++; queue.add(childId to path); continue }
                    seen++
                    when {
                        name.startsWith("~$") -> locks++
                        DOC.matches(name) || (!name.contains('.') && size > 1024) ->
                            list.add(Entry(path, size, DocumentsContract.buildDocumentUriUsingTree(tree, childId), mtime))
                        else -> other++
                    }
                    if (seen % 200 == 0) progress(id, JSONObject().put("files", seen).put("dirs", dirs).put("found", list.size))
                }
            }
        }
        val job = UUID.randomUUID().toString().substring(0, 8)
        jobs[job] = list
        resolve(id, JSONObject().put("job", job).put("count", list.size).put("locks", locks)
            .put("other", other).put("dirs", dirs).put("files", seen).put("root", rootName).put("tree", tree.toString()))
    }

    /** Entries in pages, so a huge folder never crosses the bridge as one giant string. */
    @JavascriptInterface
    fun getEntries(job: String, from: Int, count: Int): String {
        val list = jobs[job] ?: return "[]"
        val out = JSONArray()
        val end = minOf(list.size, from + count)
        for (i in from until end) out.put(JSONArray().put(list[i].path).put(list[i].size).put(list[i].mtime))
        return out.toString()
    }

    @JavascriptInterface fun releaseJob(job: String) { jobs.remove(job) }

    /** https://appassets.androidplatform.net/saf/{job}/{index} — streams one file; supports Range for ZIP. */
    fun serve(request: WebResourceRequest): WebResourceResponse {
        val parts = (request.url.path ?: "").split('/').filter { it.isNotEmpty() }
        if (parts.size != 3) return MainActivity.refuse(404, "Not Found")
        val entry = jobs[parts[1]]?.getOrNull(parts[2].toIntOrNull() ?: -1) ?: return MainActivity.refuse(404, "Not Found")
        return try {
            val afd = activity.contentResolver.openAssetFileDescriptor(entry.uri, "r")
                ?: return MainActivity.refuse(404, "Not Found")
            val total = if (entry.size >= 0) entry.size else afd.length
            val input = afd.createInputStream()
            val range = request.requestHeaders.entries.firstOrNull { it.key.equals("Range", true) }?.value
            val m = range?.let { RANGE.find(it) }
            val headers = HashMap<String, String>()
            headers["Accept-Ranges"] = "bytes"
            headers["Cache-Control"] = "no-store"
            if (m != null && total >= 0) {
                val start = m.groupValues[1].toLong()
                val end = (m.groupValues[2].toLongOrNull() ?: (total - 1)).coerceAtMost(total - 1)
                if (start > end || start >= total) { input.close(); return MainActivity.refuse(416, "Range Not Satisfiable") }
                skipFully(input, start)
                val len = end - start + 1
                headers["Content-Range"] = "bytes $start-$end/$total"
                headers["Content-Length"] = len.toString()
                WebResourceResponse("application/octet-stream", null, 206, "Partial Content", headers, Limited(input, len))
            } else {
                if (total >= 0) headers["Content-Length"] = total.toString()
                WebResourceResponse("application/octet-stream", null, 200, "OK", headers, input)
            }
        } catch (e: Exception) {
            MainActivity.refuse(500, "Read error")
        }
    }

    private fun skipFully(input: InputStream, n: Long) {
        var left = n
        while (left > 0) {
            val s = input.skip(left)
            if (s <= 0) { if (input.read() < 0) throw IOException("EOF"); left-- } else left -= s
        }
    }

    private class Limited(input: InputStream, private var left: Long) : FilterInputStream(input) {
        override fun read(): Int { if (left <= 0) return -1; val r = super.read(); if (r >= 0) left--; return r }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val r = super.read(b, off, minOf(len.toLong(), left).toInt())
            if (r > 0) left -= r
            return r
        }
        override fun available(): Int = minOf(super.available().toLong(), left).toInt()
    }

    private fun displayName(uri: Uri): String? = try {
        activity.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (_: Exception) { null }

    // ---------- saving files (DOCX, backups, CSV) in chunks ----------
    @JavascriptInterface
    fun saveBegin(name: String, mime: String): String {
        val id = UUID.randomUUID().toString()
        val f = File(activity.cacheDir, "save-$id")
        saves[id] = SaveJob(safeName(name), mime.ifBlank { "application/octet-stream" }, f, FileOutputStream(f))
        return id
    }

    @JavascriptInterface
    fun saveChunk(id: String, base64: String): Boolean {
        val s = saves[id] ?: return false
        return try { s.out.write(Base64.decode(base64, Base64.DEFAULT)); true } catch (e: Exception) { false }
    }

    @JavascriptInterface
    fun saveEnd(id: String): String {
        val s = saves.remove(id) ?: return JSONObject().put("ok", false).put("error", "нет такого сохранения").toString()
        return try {
            s.out.close()
            val where = writeOut(s)
            JSONObject().put("ok", true).put("where", where).toString()
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("error", e.message ?: e.toString()).toString()
        } finally {
            s.file.delete()
        }
    }

    private fun writeOut(s: SaveJob): String {
        val cr = activity.contentResolver
        val tree = prefs.getString("exportTree", null)?.let(Uri::parse)
        if (tree != null) {
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val doc = DocumentsContract.createDocument(cr, parent, s.mime, s.name)
                ?: throw IOException("Не удалось создать файл в выбранной папке")
            cr.openOutputStream(doc)?.use { o -> s.file.inputStream().use { it.copyTo(o) } } ?: throw IOException("Папка недоступна")
            return "папка «${displayName(parent) ?: "выбранная"}» / ${s.name}"
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, s.name)
            put(MediaStore.MediaColumns.MIME_TYPE, s.mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Выписки")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw IOException("Не удалось создать файл в «Загрузках»")
        cr.openOutputStream(uri)?.use { o -> s.file.inputStream().use { it.copyTo(o) } } ?: throw IOException("«Загрузки» недоступны")
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        cr.update(uri, values, null, null)
        return "Загрузки / Выписки / ${s.name}"
    }

    private fun safeName(n: String) = n.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").take(150).ifBlank { "file" }

    @JavascriptInterface
    fun exportFolder(): String {
        val tree = prefs.getString("exportTree", null) ?: return "Загрузки / Выписки"
        return displayName(DocumentsContract.buildDocumentUriUsingTree(Uri.parse(tree), DocumentsContract.getTreeDocumentId(Uri.parse(tree))))
            ?.let { "папка «$it»" } ?: "выбранная папка"
    }

    @JavascriptInterface
    fun chooseExportFolder(id: String) {
        pendingExport = id
        activity.runOnUiThread {
            try { activity.pickExportTree.launch(null) } catch (e: Exception) { pendingExport = null; error(id, e) }
        }
    }

    fun onExportTreePicked(uri: Uri?) {
        val id = pendingExport ?: return
        pendingExport = null
        if (uri == null) { resolve(id, JSONObject().put("cancelled", true)); return }
        try {
            activity.contentResolver.takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            prefs.edit().putString("exportTree", uri.toString()).apply()
            resolve(id, JSONObject().put("ok", true).put("where", exportFolder()))
        } catch (e: Exception) { error(id, e) }
    }

    @JavascriptInterface
    fun resetExportFolder(): String {
        prefs.edit().remove("exportTree").apply()
        return exportFolder()
    }

    // ---------- text size (accessibility): WebView text zoom, remembered between launches ----------
    @JavascriptInterface
    fun setTextZoom(percent: Int) {
        val p = percent.coerceIn(80, 160)
        prefs.edit().putInt("textZoom", p).apply()
        activity.runOnUiThread { activity.webView.settings.textZoom = p }
    }

    @JavascriptInterface fun textZoom(): Int = prefs.getInt("textZoom", 100)

    @JavascriptInterface fun setDarkBars(dark: Boolean) = activity.setBars(dark)

    // ---------- sharing a saved file (DOCX, CSV, backup) to another app ----------
    @JavascriptInterface
    fun shareBegin(name: String, mime: String): String = saveBegin(name, mime)

    @JavascriptInterface
    fun shareEnd(id: String): String {
        val s = saves.remove(id) ?: return JSONObject().put("ok", false).put("error", "нет такого файла").toString()
        return try {
            s.out.close()
            val dir = File(activity.cacheDir, "share")
            dir.mkdirs()
            dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 60 * 60 * 1000L) it.delete() }
            val target = File(dir, s.name)
            if (target.exists()) target.delete()
            if (!s.file.renameTo(target)) { s.file.copyTo(target, overwrite = true); s.file.delete() }
            val uri = FileProvider.getUriForFile(activity, activity.packageName + ".files", target)
            val send = Intent(Intent.ACTION_SEND).setType(s.mime).putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_SUBJECT, s.name).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            activity.runOnUiThread {
                try { activity.startActivity(Intent.createChooser(send, "Отправить «${s.name}»").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                catch (e: Exception) { }
            }
            JSONObject().put("ok", true).toString()
        } catch (e: Exception) {
            s.file.delete()
            JSONObject().put("ok", false).put("error", e.message ?: e.toString()).toString()
        }
    }

    // ---------- files opened with / shared to the app from other apps ----------
    @Volatile private var pendingShared: String? = null

    /** Called for every intent the activity gets; VIEW / SEND / SEND_MULTIPLE with documents become an import offer. */
    fun offerIntent(intent: Intent?) {
        if (intent == null) return
        val uris = ArrayList<Uri>()
        when (intent.action) {
            Intent.ACTION_VIEW -> intent.data?.let { uris.add(it) }
            Intent.ACTION_SEND -> streamExtra(intent)?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> streamList(intent)?.let { uris.addAll(it) }
            else -> return
        }
        intent.clipData?.let { c -> for (i in 0 until c.itemCount) c.getItemAt(i).uri?.let { if (it !in uris) uris.add(it) } }
        if (uris.isEmpty()) return
        val list = ArrayList<Entry>()
        for (u in uris) {
            var name = u.lastPathSegment?.substringAfterLast('/') ?: "файл"
            var size = -1L
            try {
                activity.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        if (!c.isNull(0)) name = c.getString(0)
                        if (!c.isNull(1)) size = c.getLong(1)
                    }
                }
            } catch (_: Exception) { }
            list.add(Entry(name, size, u, 0L))
        }
        val job = UUID.randomUUID().toString().substring(0, 8)
        jobs[job] = list
        pendingShared = JSONObject().put("job", job).put("count", list.size).put("files", list.size).put("dirs", 0)
            .put("locks", 0).put("other", 0).put("root", if (list.size == 1) list[0].path else "${list.size} файлов из другого приложения").toString()
        activity.js("window.VypiskiNativeEvents&&VypiskiNativeEvents.shared&&VypiskiNativeEvents.shared()")
    }

    @Suppress("DEPRECATION")
    private fun streamExtra(i: Intent): Uri? =
        if (android.os.Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableExtra(Intent.EXTRA_STREAM)

    @Suppress("DEPRECATION")
    private fun streamList(i: Intent): List<Uri>? =
        if (android.os.Build.VERSION.SDK_INT >= 33) i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableArrayListExtra(Intent.EXTRA_STREAM)

    @JavascriptInterface
    fun takeShared(): String { val r = pendingShared ?: ""; pendingShared = null; return r }

    // ---------- import in the background (foreground service with a progress notification) ----------
    @Volatile private var lastNote = 0L

    @JavascriptInterface
    fun importBegin(total: Int, text: String) {
        activity.runOnUiThread {
            activity.importRunning(true)
            val i = Intent(activity, ImportService::class.java).putExtra(ImportService.EXTRA_TOTAL, total)
                .putExtra(ImportService.EXTRA_DONE, 0).putExtra(ImportService.EXTRA_TEXT, text)
            try {
                if (android.os.Build.VERSION.SDK_INT >= 26) activity.startForegroundService(i) else activity.startService(i)
            } catch (e: Exception) { /* refused: the import still runs while the app is open */ }
        }
    }

    @JavascriptInterface
    fun importProgress(done: Int, total: Int, text: String) {
        val now = System.currentTimeMillis()
        if (now - lastNote < 900 && done < total) return
        lastNote = now
        activity.runOnUiThread {
            try {
                activity.startService(Intent(activity, ImportService::class.java).putExtra(ImportService.EXTRA_TOTAL, total)
                    .putExtra(ImportService.EXTRA_DONE, done).putExtra(ImportService.EXTRA_TEXT, text))
            } catch (_: Exception) { }
        }
    }

    @JavascriptInterface
    fun importEnd(text: String) {
        activity.runOnUiThread {
            activity.importRunning(false)
            try {
                activity.startService(Intent(activity, ImportService::class.java).setAction(ImportService.ACTION_DONE).putExtra(ImportService.EXTRA_TEXT, text))
            } catch (_: Exception) {
                try { activity.stopService(Intent(activity, ImportService::class.java)) } catch (_: Exception) { }
            }
        }
    }

    // ---------- printing / PDF through the Android print service ----------
    @JavascriptInterface
    fun printHtml(html: String, title: String) {
        activity.runOnUiThread {
            val w = WebView(activity)
            w.settings.javaScriptEnabled = false
            printViews.add(w)
            w.webViewClient = object : WebViewClient() {
                private var done = false
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse =
                    MainActivity.refuse(403, "Forbidden")
                override fun onPageFinished(view: WebView, url: String?) {
                    if (done) return
                    done = true
                    val pm = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val attrs = PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build()
                    pm.print(title.ifBlank { "Выписка" }, view.createPrintDocumentAdapter(title.ifBlank { "Выписка" }), attrs)
                    if (printViews.size > 3) printViews.removeAt(0).destroy()
                }
            }
            w.loadDataWithBaseURL("https://${MainActivity.HOST}/print/", html, "text/html", "utf-8", null)
        }
    }

    companion object {
        private val DOC = Regex("(?i).*\\.(docx|docm|doc|dot|dotx|rtf|zip)$")
        private val RANGE = Regex("bytes=(\\d+)-(\\d*)")
    }
}
