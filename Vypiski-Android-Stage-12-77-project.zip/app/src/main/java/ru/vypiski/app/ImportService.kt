package ru.vypiski.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * Foreground service that runs while orders are being imported.
 * The import itself happens in the page (WebView + background workers); this service only keeps the app process
 * alive and the CPU awake when the user switches to another app or turns the screen off, and shows the progress
 * in a notification. It never touches the documents and never uses the network.
 */
class ImportService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null
    private var title = "Загрузка приказов"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelfCleanly(); return START_NOT_STICKY }
            ACTION_DONE -> {
                // Final state: a normal (dismissable) notification, then the service ends.
                val text = intent.getStringExtra(EXTRA_TEXT) ?: "Загрузка приказов завершена"
                nm().notify(NOTE_DONE, build(text, 0, 0, ongoing = false))
                stopSelfCleanly()
                return START_NOT_STICKY
            }
        }
        val done = intent?.getIntExtra(EXTRA_DONE, 0) ?: 0
        val total = intent?.getIntExtra(EXTRA_TOTAL, 0) ?: 0
        intent?.getStringExtra(EXTRA_TITLE)?.let { title = it }
        val text = intent?.getStringExtra(EXTRA_TEXT) ?: "$title…"
        val note = build(text, done, total, ongoing = true)
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTE_RUN, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(NOTE_RUN, note)
        } catch (e: Exception) {
            // Starting a foreground service can be refused (e.g. from the background on Android 12+).
            // The import still continues while the app is open.
            stopSelf()
            return START_NOT_STICKY
        }
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vypiski:import").apply {
                setReferenceCounted(false)
                acquire(6 * 60 * 60 * 1000L) // safety cap: 6 hours
            }
        }
        return START_NOT_STICKY
    }

    private fun stopSelfCleanly() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        super.onDestroy()
    }

    private fun nm() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun build(text: String, done: Int, total: Int, ongoing: Boolean): Notification {
        ensureChannel(this)
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this)
        b.setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(if (ongoing) title else "Выписки")
            .setContentText(text)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
            .setShowWhen(!ongoing)
        if (ongoing) {
            if (total > 0) b.setProgress(total, done.coerceIn(0, total), false) else b.setProgress(0, 0, true)
            if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return b.build()
    }

    companion object {
        const val CHANNEL = "import"
        const val NOTE_RUN = 71
        const val NOTE_DONE = 72
        const val ACTION_STOP = "ru.vypiski.app.IMPORT_STOP"
        const val ACTION_DONE = "ru.vypiski.app.IMPORT_DONE"
        const val EXTRA_DONE = "done"
        const val EXTRA_TOTAL = "total"
        const val EXTRA_TEXT = "text"
        const val EXTRA_TITLE = "title"

        fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(NotificationChannel(CHANNEL, "Загрузка приказов", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Ход загрузки приказов и массового создания выписок, пока приложение работает в фоне"
                    setShowBadge(false)
                })
            }
        }
    }
}
