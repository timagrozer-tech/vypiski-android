package ru.vypiski.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebChromeClient.FileChooserParams
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream

/**
 * Выписки AI Enterprise X — Android shell.
 * The whole application is the offline HTML in assets/index.html, served from https://appassets.androidplatform.net
 * (a secure origin: IndexedDB, Web Workers and crypto.subtle work). Every request to any other host is refused,
 * and the manifest declares no INTERNET permission — order texts cannot leave the device.
 */
class MainActivity : ComponentActivity() {

    lateinit var webView: WebView
        private set
    private lateinit var bridge: NativeBridge
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    // <input type="file"> inside the page (files, ZIP, backup restore)
    private val pickFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        fileCallback?.onReceiveValue(uris.toTypedArray())
        fileCallback = null
    }
    private val pickOneFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        fileCallback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
        fileCallback = null
    }

    // whole folder for import, and a folder for saving excerpts
    val pickImportTree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        bridge.onImportTreePicked(uri)
    }
    val pickExportTree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        bridge.onExportTreePicked(uri)
    }

    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> }

    /** While an import runs: the page keeps full priority in the background, and (once) ask to show the progress notification. */
    @Volatile var importActive = false
        private set

    fun importRunning(on: Boolean) {
        importActive = on
        if (Build.VERSION.SDK_INT >= 26) {
            // waivedWhenNotVisible=false: the page keeps its priority when the app is in the background
            try { webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, !on) } catch (_: Exception) { }
        }
        if (on && Build.VERSION.SDK_INT >= 33) {
            val prefs = getSharedPreferences("vypiski", MODE_PRIVATE)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
                !prefs.getBoolean("askedNotifications", false)) {
                prefs.edit().putBoolean("askedNotifications", true).apply()
                try { askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS) } catch (_: Exception) { }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val debuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        WebView.setWebContentsDebuggingEnabled(debuggable)

        webView = WebView(this)
        bridge = NativeBridge(this)

        val root = FrameLayout(this)
        root.setBackgroundColor(ContextCompat.getColor(this, R.color.app_bg))
        root.addView(webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        // targetSdk 35 draws edge-to-edge: keep the page out from under the status and navigation bars and the keyboard
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
            setSupportZoom(false)
            builtInZoomControls = false
            textZoom = getSharedPreferences("vypiski", MODE_PRIVATE).getInt("textZoom", 100)
        }
        webView.addJavascriptInterface(bridge, "VypiskiNative")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url
                if (url.host != HOST) return refuse(403, "Forbidden")
                val path = url.path ?: ""
                if (path.startsWith("/saf/")) return bridge.serve(request)
                return assetLoader.shouldInterceptRequest(url) ?: refuse(404, "Not Found")
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return request.url.host != HOST // never navigate away from the app
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    if (params.mode == FileChooserParams.MODE_OPEN_MULTIPLE) pickFiles.launch(arrayOf("*/*"))
                    else pickOneFile.launch(arrayOf("*/*"))
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    callback.onReceiveValue(null)
                    false
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("(window.VypiskiOnBack ? window.VypiskiOnBack() : 'exit')") { result ->
                    if (result == null || result.contains("exit")) {
                        // during an import «Назад» only hides the app — closing it would stop the import
                        if (importActive) moveTaskToBack(true) else finish()
                    }
                }
            }
        })

        // all state lives in IndexedDB, so a fresh load after process death restores everything
        webView.loadUrl("https://$HOST/assets/index.html")
        if (savedInstanceState == null) bridge.offerIntent(intent)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        bridge.offerIntent(intent)
    }

    fun keepScreenOn(on: Boolean) {
        runOnUiThread {
            if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    fun js(code: String) {
        runOnUiThread { webView.evaluateJavascript(code, null) }
    }

    override fun onDestroy() {
        webView.removeJavascriptInterface("VypiskiNative")
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        const val HOST = "appassets.androidplatform.net"

        fun refuse(code: Int, reason: String): WebResourceResponse =
            WebResourceResponse("text/plain", "utf-8", code, reason, emptyMap(), ByteArrayInputStream(ByteArray(0)))
    }
}
