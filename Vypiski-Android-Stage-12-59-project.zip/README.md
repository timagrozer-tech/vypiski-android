# Выписки — Android (Stage 12.59)

This is a minimal offline Android WebView wrapper around the original single-file HTML application.

## Build on GitHub from a phone

1. Upload the **contents** of this ZIP to the repository root (not inside an extra folder).
2. Open **Actions → Build Android APK → Run workflow** (or let the push trigger it).
3. Open the successful workflow run → **Artifacts** → `Vypiski-Stage-12-59-debug-APK`.
4. Download the artifact ZIP, extract `app-debug.apk`, and install it on Android.

It uses Android API 29+ (Android 10+), JDK 17, Gradle 8.9 and AGP 8.7.3.
The debug APK is suitable for testing, not a signed Play Store release.

## Notes and limitations

- Original HTML is packaged without modifying its document processing logic.
- Documents remain in Android WebView's IndexedDB app storage. Uninstalling the app deletes this data. Use the app's backup/export features regularly.
- Select ZIP/DOCX/files using the native Android file picker. Directory picking via `<input webkitdirectory>` is **not guaranteed** in WebView; upload a ZIP instead.
- Blob downloads triggered via anchors with the `download` attribute are exported to `Downloads/Выписки` through an Android bridge. Other export mechanisms have not been validated.
- Large exports are base64-encoded in memory; test with realistic files before production use.
- The source HTML contains no external script tags; no Internet permission is requested.
- Treat unknown imported office/ZIP files as untrusted; tests are required before using real sensitive documents.
