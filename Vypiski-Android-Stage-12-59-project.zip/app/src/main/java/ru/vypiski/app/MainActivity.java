package ru.vypiski.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int FILE_PICKER_CODE = 1001;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new ExportBridge(), "VypiskiAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (!"appassets.androidplatform.net".equals(request.getUrl().getHost())) return null;
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !("https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost())
                        && uri.getPath() != null && uri.getPath().startsWith("/assets/"));
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (url.startsWith("https://appassets.androidplatform.net/assets/")) {
                    view.evaluateJavascript(EXPORT_SHIM, null);
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try { startActivityForResult(intent, FILE_PICKER_CODE); }
                catch (ActivityNotFoundException err) {
                    fileCallback.onReceiveValue(null); fileCallback = null;
                    Toast.makeText(MainActivity.this, "Не найден файловый менеджер", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    // Intercept blob URL downloads so exports from the HTML app reach Android Downloads.
    private static final String EXPORT_SHIM = "(function(){if(window.__vypiskiExportReady)return;window.__vypiskiExportReady=true;" +
            "document.addEventListener('click',async function(e){" +
            "var a=e.target&&e.target.closest&&e.target.closest('a[download]');" +
            "if(!a||!a.href||!a.href.startsWith('blob:'))return;" +
            "e.preventDefault();e.stopImmediatePropagation();" +
            "try{var r=await fetch(a.href);var b=await r.blob();var f=new FileReader();" +
            "f.onload=function(){window.VypiskiAndroid.saveBase64(f.result,a.download||'export.bin')};f.readAsDataURL(b);" +
            "}catch(err){alert('Ошибка сохранения: '+err.message)}" +
            "},true);})();";

    public class ExportBridge {
        @JavascriptInterface public void saveBase64(String dataUri, String name) {
            try {
                int comma = dataUri.indexOf(',');
                if (comma < 0 || !dataUri.substring(0, comma).contains(";base64")) throw new IllegalArgumentException("Not base64");
                byte[] bytes = Base64.decode(dataUri.substring(comma + 1), Base64.DEFAULT);
                String safeName = name.replaceAll("[\\/\\r\\n]", "_").trim();
                if (safeName.isEmpty()) safeName = "vypiski-export.bin";
                String lower = safeName.toLowerCase(Locale.ROOT);
                String mime = lower.endsWith(".docx") ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" :
                         lower.endsWith(".zip") ? "application/zip" : lower.endsWith(".pdf") ? "application/pdf" :
                         lower.endsWith(".txt") ? "text/plain" : "application/octet-stream";
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Выписки");
                v.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new IllegalStateException("No destination");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("No output stream");
                    out.write(bytes);
                } catch (Exception error) {
                    getContentResolver().delete(uri, null, null);
                    throw error;
                }
                v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, v, null, null);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Сохранено в Загрузки/Выписки", Toast.LENGTH_LONG).show());
            } catch (Exception error) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Ошибка экспорта: " + error.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_PICKER_CODE || fileCallback == null) return;
        Uri[] selected = null;
        if (resultCode == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null) {
                selected = new Uri[clip.getItemCount()];
                for (int i = 0; i < clip.getItemCount(); i++) selected[i] = clip.getItemAt(i).getUri();
            } else if (data.getData() != null) selected = new Uri[]{data.getData()};
        }
        fileCallback.onReceiveValue(selected);
        fileCallback = null;
    }
    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        webView.destroy();
        super.onDestroy();
    }
}
